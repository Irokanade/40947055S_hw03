#include <stdio.h>

//this is a comment onetwothree

int newFunc(int newVarTwo);

int main() {
    int one = 4001;
    int var = 20;
    char str[] = "Hello Kitty";

    int newVar = newFunc(var);

    printf("one: %d\n", one);
    printf("newVar: %d\n", newVar);
    printf("%s\n", str);

    return 0;
}

int newFunc(int newVarTwo) {
    return newVarTwo + 2;
}